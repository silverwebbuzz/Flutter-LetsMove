const String iconLogo = "assets/images/logo2.png";
const String nameLogo = "assets/images/logo.png";

const String mainBanner = "assets/images/banner.jpg";

const String sliderTech = "assets/images/tecnology.jpg";
const String sliderHand = "assets/images/letsmove-ger.jpg";
const String sliderMoney = "assets/images/completed-transection.jpg";

const String sliderfeature1 = "assets/images/feature1.jpg";
const String sliderfeature2 = "assets/images/feature2.jpg";
const String sliderfeature3 = "assets/images/feature3.jpg";

const String slidernews1 = "assets/images/news1.jpg";
const String slidernews2 = "assets/images/news2.jpg";
const String slidernews3 = "assets/images/news3.jpg";

const String imgLive = "assets/images/live.jpg";

const String imgInvestor = "assets/images/investor.png";

const String imgEnd = "assets/images/end.jpg";