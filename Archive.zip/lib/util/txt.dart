class Txt {
  static const String appName = "LetsMove.gr";
  static const String appDesc = "LetsMove for your happy";
  static const String forgotDesc = "Enter your registered email address";
  static const String alreadyUser = "Already have an account ? SIGNIN";
  static const String newUser = "Don't have an account ? SIGNUP";
  static const String goBack = "Go Back";
}